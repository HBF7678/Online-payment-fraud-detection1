# Online-Fraud-Detection-ML-Project
 Dataset Link - https://www.kaggle.com/datasets/jainilcoder/online-payment-fraud-detection

### Input Features
* type - "CASH_OUT" : 1,
         "PAYMENT" : 2,
         "CASH_IN" : 3,
         "TRANSFER" : 4,
         'DEBIT': 5
* amount
* oldbalanceOrg
* newbalanceOrig

### Output Feature
* isFraud - 0 - Not Fraud
            1 - Fraud

* Add your dataset in the source file!

  ![Screenshot 2024-02-24 164108](https://github.com/Pragna235/Online-Payment-Fraud-Detection-ML-Project/assets/109524200/68da6dfe-8752-44df-873c-ee7b03b9adaa)

